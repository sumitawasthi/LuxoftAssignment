package org.luxoft.SudokoValidator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.junit.Before;
import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class AppTest

{

	int sudoko[][];
	int invalidSudoko[][];
	App ap;

	@Before
	public void beforeStart() {
		sudoko = new int[][] { { 1, 2, 3, 4, 5, 6, 7, 8, 9 }, { 2, 3, 4, 5, 6, 7, 8, 9, 1 },
				{ 3, 4, 5, 6, 7, 8, 9, 1, 2 }, { 4, 5, 6, 7, 8, 9, 1, 2, 3 }, { 5, 6, 7, 8, 9, 1, 2, 3, 4 },
				{ 6, 7, 8, 9, 1, 2, 3, 4, 5 }, { 7, 8, 9, 1, 2, 3, 4, 5, 6 }, { 8, 9, 1, 2, 3, 4, 5, 6, 7 },
				{ 9, 1, 2, 3, 4, 5, 6, 7, 8 } };

		invalidSudoko = new int[][] { { 1, 2, 3, 4, 5, 6, 7, 8, 9 }, { 2, 3, 4, 5, 6, 7, 8, 9, 1 },
				{ 3, 4, 5, 6, 7, 8, 9, 1, 2 }, { 4, 5, 6, 7, 8, 9, 1, 2, 3 }, { 5, 6, 7, 8, 9, 1, 2, 3, 4 },
				{ 6, 7, 8, 9, 1, 2, 3, 4, 5 }, { 7, 8, 9, 1, 2, 3, 4, 5, 6 }, { 8, 9, 1, 2, 3, 4, 5, 6, 7 },
				{ 9, 1, 2, 3, 4, 5, 9, 7, 8 } };

		ap = new App();
	}

	@SuppressWarnings("static-access")
	@Test
	public void validCheck() {
		assertTrue(ap.validSudoko(sudoko));
	}

	@SuppressWarnings("static-access")
	@Test
	public void invalidReadCheck() {
		assertThrows(FileNotFoundException.class, () -> ap.readCSV("valid.csv"));
	}

	@SuppressWarnings("static-access")
	@Test
	public void validReadCheck() {
		// assertThrows(FileNotFoundException.class, () -> ap.readCSV("valid.csv"));
		try {
			assertEquals(sudoko.length, ap.readCSV("F:\\\\data\\\\sudoko.csv").length);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@SuppressWarnings("static-access")
	@Test
	public void assertMain() {
		assertEquals("0", ap.checkSudoko("F:\\\\data\\\\sudoko.csv"));
	}

	@SuppressWarnings("static-access")
	@Test
	public void inValidCheck() {
		assertFalse(ap.validSudoko(invalidSudoko));
	}

	@Test
	public void arrayRowCheck() {
		assertTrue(sudoko.length == 9);
	}

	@Test
	public void arrayColumnCheck() {
		assertTrue(sudoko[0].length == 9);
	}
}
