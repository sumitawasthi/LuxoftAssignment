package org.luxoft.SudokoValidator;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {

		String file = args[0];
		System.out.println("File given to verify :" + file);
		System.out.println();
		System.out.println("Hello, Running sudoko verification if 0 great! it works else sorry invalid sudoko");
		System.out.println();
		System.out.println(checkSudoko(file));
	}

	public static String checkSudoko(String file) {
		int sudoko[][] = null;
		try {
			sudoko = readCSV(file);
		} catch (IOException e) {
			return "1 Invalid File Path " + e;
		}
		if (checkArray(sudoko)) {
			if (validSudoko(sudoko)) {
				return "0";
			} else {
				return "1 Sorry not valid";
			}
		} else {
			return "1 Sorry not valid";
		}
	}

	public static int[][] readCSV(String path) throws FileNotFoundException, IOException {
		BufferedReader br = new BufferedReader(new FileReader(path));
		String line;
		String[] elems = null;
		List<String[]> l = new ArrayList<String[]>();
		while ((line = br.readLine()) != null) {
			elems = line.split(",");
			l.add(elems);
		}
		br.close();
		int rows = l.size();
		int cols = l.get(0).length;
		int[][] array2D = new int[rows][cols];
		for (int row = 0; row < rows; row++) {
			for (int col = 0; col < cols; col++) {
				array2D[row][col] = Integer.parseInt(l.get(row)[(col)]);
			}
		}
		return array2D;
	}

	public static boolean checkArray(int sudoko[][]) {
		if (sudoko.length != 9) {
			return false;
		}
		for (int i = 0; i < sudoko.length; i++) {
			if (sudoko[i].length != 9) {
				return false;
			}
		}
		return true;
	}

	public static boolean validSudoko(int sudoko[][]) {
		HashSet<Integer> hash = null;
		for (int i = 0; i < sudoko.length; i++) {
			hash = new HashSet<Integer>();
			for (int j = 0; j < sudoko[i].length; j++) {
				if (hash.contains(sudoko[i][j]) || hash.contains(sudoko[j][i]) || sudoko[i][j] > 9
						|| sudoko[i][j] < 1) {
					return false;
				}
				hash.add(sudoko[i][j]);
				hash.add(sudoko[j][i]);
			}
		}
		return true;
	}
}
